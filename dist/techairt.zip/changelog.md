* [7c87383](https://github.com/TryGhost/Casper/commit/7c87383) 3.0.6 - Fabien O'Carroll
* [09d701c](https://github.com/TryGhost/Casper/commit/09d701c) 🐛 Removed non-existent variable - Peter Zimon
* [aec67d8](https://github.com/TryGhost/Casper/commit/aec67d8) 2020 - John O'Nolan
* [f55e2b0](https://github.com/TryGhost/Casper/commit/f55e2b0) Update dependency gscan to v3.2.1 - Renovate Bot
